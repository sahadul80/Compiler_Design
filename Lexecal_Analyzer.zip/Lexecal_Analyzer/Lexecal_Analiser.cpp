#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>

using namespace std;

bool isKeyword(const string &word, ifstream &tokens)
{
    string key;
    char sp_ch, num, op;

    tokens.clear();
    tokens.seekg(0);

    while (tokens >> key)
    {
        if (word == key)
        {
            return true;
        }
    }

    return false;
}

bool isIdentifier(const string &word)
{
    if (isalpha(word[0]) || word[0] == '_')
    {
        for (char c : word)
        {
            if (!isalnum(c) && c != '_')
            {
                return false;
            }
        }
        return true;
    }
    return false;
}

bool isConstant(const string &word)
{
    char num[] = ".0123456789";
    bool isNum = false;
    bool isString = false;

    if (word.size() >= 2 && word[0] == '"' && word[word.size() - 1] == '"')
    {
        isString = true;
    }
    else
    {
        for (char c : word)
        {
            if (strchr(num, c) == nullptr)
            {
                return false;
            }
            isNum = true;
        }
    }

    return isNum || isString;
}

bool isPunctuation(const string &word)
{
    string punctuations = ";,(){}[]";

    return punctuations.find(word) != string::npos;
}

bool isOperator(const string &word)
{
    string operators = "+-*/%=><!";

    return operators.find(word) != string::npos;
}

void lexeme_Analyzer(const string &str, ifstream &tokens)
{
    istringstream stream(str);
    string part, keywords;

    while (stream >> part)
    {
        if (isKeyword(part, tokens))
        {
            keywords += part;
        }
        else
        {
            string operators, identifiers, punctuations, constants;

            for (char c : part)
            {
                string singleChar(1, c);
                if (isConstant(singleChar))
                {
                    constants += c;
                }
                else if (isPunctuation(singleChar))
                {
                    punctuations += c;
                }
                else if (isOperator(singleChar))
                {
                    operators += c;
                }
                else if (isIdentifier(singleChar))
                {
                    identifiers += c;
                }
                else
                {
                    cout << "Syntax ERROR!" << endl;
                }
            }
            if (!constants.empty())
            {
                cout << "Constants: " << constants << endl;
            }
            else
            {
                cout << "No Constant Found!" << endl;
            }
            if (!punctuations.empty())
            {
                cout << "Punctuations: " << punctuations << endl;
            }
            else
            {
                cout << "No Punctuation Found!" << endl;
            }
            if (!operators.empty())
            {
                cout << "Operators: " << operators << endl;
            }
            else
            {
                cout << "No Operator Found!" << endl;
            }
            if (!identifiers.empty())
            {
                cout << "Identifiers: " << identifiers << endl;
            }
            else
            {
                cout << "No Identifier Found!" << endl;
            }
        }
    }
    if (!keywords.empty())
    {
        cout << "Keywords: " << keywords << endl;
    }else
    {
        cout << "No Keyword Found!" << endl;
    }
}

void syntax()
{
    ifstream tokens("Tokens.txt");

    if (!tokens.is_open())
    {
        cout << "Error opening Tokens.txt file!" << endl;
        return;
    }

    string s;
    cout << "Expression to Analyse: ";
    getline(cin, s);

    lexeme_Analyzer(s, tokens);

    tokens.close();
}

int main()
{
    syntax();
    return 0;
}
